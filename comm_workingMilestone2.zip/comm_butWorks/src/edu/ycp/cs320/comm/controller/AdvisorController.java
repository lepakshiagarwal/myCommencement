package edu.ycp.cs320.comm.controller;

import java.util.ArrayList;

import edu.ycp.cs320.comm.model.Advisor;
import edu.ycp.cs320.comm.model.Student;

/**
 * Controller for the Advisor
 */
public class AdvisorController {
	private Advisor model;

	 //Set the model.
	public AdvisorController(Advisor model) {
		this.model = model;
	}
	
	//method to getAdvisee
	public Student getAdvisee(String name) {
		return model.getAdvisee(name);
	}
	
	//adds new advisee
	public void addAdvisee(Student s)
	{
		model.addAdvisee(s);
	}
	
	//method to validate password
	public boolean validateCredentials(String name, String password)
	{
		return model.validatePassword(name, password);
	}
	
	//method to get advices list for a advisor
	public ArrayList<Student> getAdviseeList(){
		return model.adviseeList();
	}
}