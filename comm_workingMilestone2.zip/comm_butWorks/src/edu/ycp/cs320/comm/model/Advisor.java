package edu.ycp.cs320.comm.model;

import java.util.ArrayList;

public class Advisor extends User
{
	private ArrayList<Student> advisees;
	
	public Advisor() 
	{
		//instantiate null advisor
		super(null, null);
		advisees = new ArrayList<Student>();
	}
	
	
	//adds new advisee
	public void addAdvisee(Student s)
	{
		advisees.add(s);
	}
	
	
	
	//finds student if it exists
	public Student getAdvisee(String username) 
	{
		try
		{
			for(Student s : advisees)
			{
				if(s.getUsername().equals(username))
				{
					return s;
				}
			}
		}
		catch(NullPointerException e)
		{
			System.out.print("Null pointer exception, no advisees for advisor");
		}
		return null;
	}
	
	//finds student and validates password
	public boolean validatePassword(String name, String pass) 
	{
		if(username== null || password==null)
		{
			System.out.print("No username and password");
		}
		if(name.equals(username) && pass.equals(password))
		{
			return true;
		}
		return false;
		
	}
		
	public ArrayList<Student> adviseeList()
	{
		return advisees;
	}
}