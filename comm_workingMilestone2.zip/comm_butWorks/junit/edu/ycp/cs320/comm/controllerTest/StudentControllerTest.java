package edu.ycp.cs320.comm.controllerTest;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.junit.Before;
import org.junit.Test;

import edu.ycp.cs320.comm.controller.AdvisorController;
import edu.ycp.cs320.comm.controller.StudentController;
import edu.ycp.cs320.comm.model.Advisor;
import edu.ycp.cs320.comm.model.Student;

public class StudentControllerTest {
	private Student model;
	private StudentController controller;
	
	@Before
	public void setUp() {
		model = new Student();
		controller=new StudentController(model);
	}
	
	@Test
	public void testValidateUsername() {
		assertFalse(controller.checkUserName("lepakshi"));
	}
	@Test
	public void testValidateUsernamee() {
		assertTrue(controller.checkUserName("Mshae"));
	}
	
	@Test
	public void testValidatePassword() {
		assertTrue(controller.validateCredentials("Mshae","xyz"));
	}
	
	@Test 
	public void testValidatePasswordd() {
		assertFalse(controller.validateCredentials("Rshae","xyz"));
	}
	
	@Test
	public void testGetAdviceList() {
		List<String> test=new ArrayList<String>();
		test.add("lepakshi");
		test.add("jake");
		String Advisor="Mshae";
		assertTrue(model.adviceList(Advisor)== test);
	}
}
