package edu.ycp.cs320.comm.controller;

import edu.ycp.cs320.comm.model.Advisor;

/**
 * Controller for the Advisor
 */
public class AdvisorController {
	private Advisor model;

	 //Set the model.
	public void setModel(Advisor model) {
		this.model = model;
	}
}
