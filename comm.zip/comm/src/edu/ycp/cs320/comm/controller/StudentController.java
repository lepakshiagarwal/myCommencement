package edu.ycp.cs320.comm.controller;

import edu.ycp.cs320.comm.model.Student;

//controller for student
public class StudentController {
	private Student model;

	//Set the model.
	
	public void setModel(Student model) {
		this.model = model;
	}
}
