package edu.ycp.cs320.comm.model;

public class Advisor extends User{

	//advisor is a user 
	public Advisor(String username, String password) {
		super(username, password);
	}
}
