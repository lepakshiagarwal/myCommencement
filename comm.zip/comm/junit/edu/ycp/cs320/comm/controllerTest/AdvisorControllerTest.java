package edu.ycp.cs320.comm.controllerTest;

public class AdvisorControllerTest {

}
